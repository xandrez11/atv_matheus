import minhabiblioteca as mb

vetor=[5,7,4,4,7,3]
print(vetor)
mb.selecao_ordenacao(vetor)
print(vetor)